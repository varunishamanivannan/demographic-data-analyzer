# Demographic Data Analyzer

This project uses Pandas to analyze 1994 U.S. Census data.