from demographic_data_analyzer import calculate_demographic_data

if __name__ == "__main__":
    calculate_demographic_data()